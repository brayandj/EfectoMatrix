const canvas = document.querySelector('canvas')
canvas.width = 300
canvas.height = 300
const ctx = canvas.getContext('2d')
ctx.fillRect(0, 0, canvas.width, canvas.height)